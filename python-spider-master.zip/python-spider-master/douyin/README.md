## 功能

下载指定用户的抖音视频。

## 作者

* Author: [Jack Cui](http://cuijiahua.com "悬停显示")、[steven7851](https://github.com/steven7851 "悬停显示")

## 运行效果

![image](https://github.com/Jack-Cherish/Pictures/blob/master/14.gif)

## 使用说明

	python douyin.py

签名服务来源：https://github.com/coder-fly/douyin-signature<br />
也可以使用 pyppeteer 模拟浏览器来取得签名，如此就不必依赖服务<br />
要是以后服务器关了再来弄吧。 。
